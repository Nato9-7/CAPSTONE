-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: rbalerta_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `rbalerta_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `rbalerta_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `rbalerta_db`;

--
-- Table structure for table `categoria_incidente`
--

DROP TABLE IF EXISTS `categoria_incidente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_incidente` (
  `id_categoria` smallint unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `icono` varchar(60) DEFAULT NULL,
  `color_hex` char(7) DEFAULT NULL,
  `nivel_gravedad` tinyint unsigned NOT NULL DEFAULT '3',
  `radio_difusion_metros` smallint unsigned NOT NULL DEFAULT '1000',
  `id_entidad` smallint unsigned DEFAULT NULL,
  `horas_vigencia` smallint unsigned NOT NULL DEFAULT '24',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `uq_categoria_cod` (`codigo`),
  KEY `fk_categoria_entidad` (`id_entidad`),
  CONSTRAINT `fk_categoria_entidad` FOREIGN KEY (`id_entidad`) REFERENCES `entidad_emergencia` (`id_entidad`) ON DELETE SET NULL,
  CONSTRAINT `chk_categoria_gravedad` CHECK ((`nivel_gravedad` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_incidente`
--

LOCK TABLES `categoria_incidente` WRITE;
/*!40000 ALTER TABLE `categoria_incidente` DISABLE KEYS */;
INSERT INTO `categoria_incidente` VALUES (1,'ROBO','Robo o asalto','shield-alert','#C2410C',4,1500,1,12,1),(2,'ACCIDENTE','Accidente de tránsito','car-crash','#B91C1C',4,2000,2,6,1),(3,'INCENDIO','Incendio','flame','#DC2626',5,3000,2,6,1),(4,'EMERGENCIA','Emergencia médica','heart-pulse','#DB2777',5,1000,3,4,1),(5,'MASCOTA','Mascota perdida','paw-print','#0369A1',1,2000,NULL,168,1),(6,'VIAL','Problema en la vía','traffic-cone','#CA8A04',2,1000,NULL,48,1);
/*!40000 ALTER TABLE `categoria_incidente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentario`
--

DROP TABLE IF EXISTS `comentario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentario` (
  `id_comentario` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_reporte` bigint unsigned NOT NULL,
  `id_usuario` bigint unsigned NOT NULL,
  `contenido` varchar(500) NOT NULL,
  `estado` enum('PUBLICADO','OCULTO','ELIMINADO') NOT NULL DEFAULT 'PUBLICADO',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_comentario`),
  KEY `fk_comentario_usuario` (`id_usuario`),
  KEY `idx_comentario_reporte` (`id_reporte`,`estado`,`fecha_creacion`),
  CONSTRAINT `fk_comentario_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `fk_comentario_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentario`
--

LOCK TABLES `comentario` WRITE;
/*!40000 ALTER TABLE `comentario` DISABLE KEYS */;
/*!40000 ALTER TABLE `comentario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comuna`
--

DROP TABLE IF EXISTS `comuna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comuna` (
  `id_comuna` int unsigned NOT NULL AUTO_INCREMENT,
  `id_region` smallint unsigned NOT NULL,
  `codigo_cut` char(5) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `centroide` point /*!80003 SRID 4326 */ DEFAULT NULL,
  `limite` polygon /*!80003 SRID 4326 */ DEFAULT NULL,
  `operativa` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_comuna`),
  UNIQUE KEY `uq_comuna_cut` (`codigo_cut`),
  KEY `idx_comuna_region` (`id_region`),
  CONSTRAINT `fk_comuna_region` FOREIGN KEY (`id_region`) REFERENCES `region` (`id_region`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comuna`
--

LOCK TABLES `comuna` WRITE;
/*!40000 ALTER TABLE `comuna` DISABLE KEYS */;
INSERT INTO `comuna` VALUES (1,1,'10101','Puerto Montt',_binary '\�\0\0\0\0\0\�HP<R����D�',NULL,1),(2,1,'10201','Castro',NULL,NULL,0),(3,1,'10301','Osorno',NULL,NULL,0);
/*!40000 ALTER TABLE `comuna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entidad_emergencia`
--

DROP TABLE IF EXISTS `entidad_emergencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entidad_emergencia` (
  `id_entidad` smallint unsigned NOT NULL AUTO_INCREMENT,
  `id_comuna` int unsigned NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('CARABINEROS','BOMBEROS','SAMU','SEGURIDAD_CIUDADANA','OTRO') NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ubicacion` point /*!80003 SRID 4326 */ DEFAULT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_entidad`),
  KEY `idx_entidad_comuna` (`id_comuna`,`activa`),
  CONSTRAINT `fk_entidad_comuna` FOREIGN KEY (`id_comuna`) REFERENCES `comuna` (`id_comuna`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entidad_emergencia`
--

LOCK TABLES `entidad_emergencia` WRITE;
/*!40000 ALTER TABLE `entidad_emergencia` DISABLE KEYS */;
INSERT INTO `entidad_emergencia` VALUES (1,1,'Carabineros de Chile','CARABINEROS','133',NULL,NULL,1),(2,1,'Bomberos de Puerto Montt','BOMBEROS','132',NULL,NULL,1),(3,1,'SAMU','SAMU','131',NULL,NULL,1),(4,1,'Seguridad Ciudadana Municipal','SEGURIDAD_CIUDADANA','800600100',NULL,NULL,1);
/*!40000 ALTER TABLE `entidad_emergencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localidad`
--

DROP TABLE IF EXISTS `localidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localidad` (
  `id_localidad` int unsigned NOT NULL AUTO_INCREMENT,
  `id_comuna` int unsigned NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('URBANA','RURAL','SECTOR') NOT NULL DEFAULT 'SECTOR',
  `centroide` point /*!80003 SRID 4326 */ DEFAULT NULL,
  `limite` polygon /*!80003 SRID 4326 */ DEFAULT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_localidad`),
  UNIQUE KEY `uq_localidad_comuna_nombre` (`id_comuna`,`nombre`),
  KEY `idx_localidad_comuna` (`id_comuna`,`activa`),
  CONSTRAINT `fk_localidad_comuna` FOREIGN KEY (`id_comuna`) REFERENCES `comuna` (`id_comuna`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localidad`
--

LOCK TABLES `localidad` WRITE;
/*!40000 ALTER TABLE `localidad` DISABLE KEYS */;
INSERT INTO `localidad` VALUES (1,1,'Centro','URBANA',NULL,NULL,1),(2,1,'Alerce','URBANA',NULL,NULL,1),(3,1,'Mirasol','URBANA',NULL,NULL,1),(4,1,'Pelluco','URBANA',NULL,NULL,1),(5,1,'Chinquihue','SECTOR',NULL,NULL,1),(6,1,'Puerto Chico','URBANA',NULL,NULL,1);
/*!40000 ALTER TABLE `localidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localidad_estadistica`
--

DROP TABLE IF EXISTS `localidad_estadistica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localidad_estadistica` (
  `id_estadistica` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_localidad` int unsigned NOT NULL,
  `periodo` date NOT NULL,
  `total_reportes` int unsigned NOT NULL DEFAULT '0',
  `reportes_validados` int unsigned NOT NULL DEFAULT '0',
  `indice_riesgo` decimal(5,2) NOT NULL DEFAULT '0.00',
  `fecha_calculo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estadistica`),
  UNIQUE KEY `uq_estadistica_periodo` (`id_localidad`,`periodo`),
  KEY `idx_estadistica_periodo` (`periodo`,`indice_riesgo`),
  CONSTRAINT `fk_estadistica_localidad` FOREIGN KEY (`id_localidad`) REFERENCES `localidad` (`id_localidad`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localidad_estadistica`
--

LOCK TABLES `localidad_estadistica` WRITE;
/*!40000 ALTER TABLE `localidad_estadistica` DISABLE KEYS */;
/*!40000 ALTER TABLE `localidad_estadistica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacion`
--

DROP TABLE IF EXISTS `notificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificacion` (
  `id_notificacion` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `id_reporte` bigint unsigned NOT NULL,
  `id_dispositivo` bigint unsigned DEFAULT NULL,
  `id_zona_segura` bigint unsigned DEFAULT NULL,
  `motivo` enum('ZONA_SEGURA','PROXIMIDAD','SEGUIMIENTO') NOT NULL,
  `distancia_metros` int unsigned DEFAULT NULL,
  `estado_envio` enum('PENDIENTE','ENVIADA','ENTREGADA','FALLIDA') NOT NULL DEFAULT 'PENDIENTE',
  `fecha_envio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_lectura` datetime DEFAULT NULL,
  PRIMARY KEY (`id_notificacion`),
  KEY `fk_notif_dispositivo` (`id_dispositivo`),
  KEY `fk_notif_zona` (`id_zona_segura`),
  KEY `idx_notif_usuario_fecha` (`id_usuario`,`fecha_envio`),
  KEY `idx_notif_no_leidas` (`id_usuario`,`fecha_lectura`),
  KEY `idx_notif_reporte` (`id_reporte`),
  CONSTRAINT `fk_notif_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `usuario_dispositivo` (`id_dispositivo`) ON DELETE SET NULL,
  CONSTRAINT `fk_notif_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `fk_notif_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `fk_notif_zona` FOREIGN KEY (`id_zona_segura`) REFERENCES `zona_segura` (`id_zona_segura`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacion`
--

LOCK TABLES `notificacion` WRITE;
/*!40000 ALTER TABLE `notificacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `notificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `region` (
  `id_region` smallint unsigned NOT NULL AUTO_INCREMENT,
  `codigo_cut` char(2) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `numero_romano` varchar(6) DEFAULT NULL,
  `orden` smallint unsigned NOT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_region`),
  UNIQUE KEY `uq_region_cut` (`codigo_cut`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'10','Los Lagos','X',14,1);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporte`
--

DROP TABLE IF EXISTS `reporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporte` (
  `id_reporte` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `id_categoria` smallint unsigned NOT NULL,
  `id_comuna` int unsigned NOT NULL,
  `id_localidad` int unsigned DEFAULT NULL,
  `ubicacion` point NOT NULL /*!80003 SRID 4326 */,
  `direccion_referencia` varchar(255) DEFAULT NULL,
  `descripcion` varchar(500) NOT NULL,
  `estado` enum('PENDIENTE','VALIDADO','DESCARTADO','RESUELTO','EXPIRADO') NOT NULL DEFAULT 'PENDIENTE',
  `es_anonimo` tinyint(1) NOT NULL DEFAULT '0',
  `total_confirmaciones` int unsigned NOT NULL DEFAULT '0',
  `total_desmentidos` int unsigned NOT NULL DEFAULT '0',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fecha_expiracion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_reporte`),
  KEY `fk_reporte_localidad` (`id_localidad`),
  SPATIAL KEY `spx_reporte_ubicacion` (`ubicacion`),
  KEY `idx_reporte_estado_fecha` (`estado`,`fecha_creacion`),
  KEY `idx_reporte_comuna_fecha` (`id_comuna`,`fecha_creacion`),
  KEY `idx_reporte_usuario` (`id_usuario`,`fecha_creacion`),
  KEY `idx_reporte_categoria` (`id_categoria`,`estado`),
  CONSTRAINT `fk_reporte_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_incidente` (`id_categoria`) ON DELETE RESTRICT,
  CONSTRAINT `fk_reporte_comuna` FOREIGN KEY (`id_comuna`) REFERENCES `comuna` (`id_comuna`) ON DELETE RESTRICT,
  CONSTRAINT `fk_reporte_localidad` FOREIGN KEY (`id_localidad`) REFERENCES `localidad` (`id_localidad`) ON DELETE SET NULL,
  CONSTRAINT `fk_reporte_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporte`
--

LOCK TABLES `reporte` WRITE;
/*!40000 ALTER TABLE `reporte` DISABLE KEYS */;
INSERT INTO `reporte` VALUES (9,10,3,1,NULL,_binary '\�\0\0\0\0\0	��;R�D���D�','Regimiento, Puerto Montt','se esta quemando una casa','PENDIENTE',0,0,0,'2026-09-19 21:11:25','2026-09-19 21:11:25','2026-09-20 00:11:25'),(15,10,3,1,NULL,_binary '\�\0\0\0\0\0���0>;R��\�o\"�D�','Tucapel, Puerto Montt','se esta quemando mi casa','RESUELTO',0,0,0,'2026-09-21 12:10:53','2026-09-21 12:11:12','2026-09-21 15:10:53'),(16,10,1,1,NULL,_binary '\�\0\0\0\0\0t,>;R��YC!�D�','Tucapel, Puerto Montt','me  robaron en la calle','RESUELTO',0,0,0,'2026-09-21 12:11:46','2026-09-21 12:12:15','2026-09-21 21:11:46'),(17,10,1,1,NULL,_binary '\�\0\0\0\0\0ޔ\�8>;R�\�S߮\"�D�','Tucapel, Puerto Montt','me robaron el auto','PENDIENTE',0,0,0,'2026-09-21 12:13:48','2026-09-21 12:13:48','2026-09-21 21:13:48'),(18,10,1,1,NULL,_binary '\�\0\0\0\0\0�\�=;R�?\� �D�','Tucapel, Puerto Montt','roboo','PENDIENTE',0,0,0,'2026-09-21 12:18:35','2026-09-21 12:18:35','2026-09-21 21:18:35');
/*!40000 ALTER TABLE `reporte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporte_estado_historial`
--

DROP TABLE IF EXISTS `reporte_estado_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporte_estado_historial` (
  `id_historial` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_reporte` bigint unsigned NOT NULL,
  `estado_anterior` enum('PENDIENTE','VALIDADO','DESCARTADO','RESUELTO','EXPIRADO') NOT NULL,
  `estado_nuevo` enum('PENDIENTE','VALIDADO','DESCARTADO','RESUELTO','EXPIRADO') NOT NULL,
  `id_usuario_responsable` bigint unsigned DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `fecha_cambio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historial`),
  KEY `fk_historial_usuario` (`id_usuario_responsable`),
  KEY `idx_historial_reporte` (`id_reporte`,`fecha_cambio`),
  CONSTRAINT `fk_historial_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `fk_historial_usuario` FOREIGN KEY (`id_usuario_responsable`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporte_estado_historial`
--

LOCK TABLES `reporte_estado_historial` WRITE;
/*!40000 ALTER TABLE `reporte_estado_historial` DISABLE KEYS */;
INSERT INTO `reporte_estado_historial` VALUES (3,15,'PENDIENTE','RESUELTO',10,'Marcado como resuelto por quien lo reportó','2026-09-21 12:11:12'),(4,16,'PENDIENTE','RESUELTO',10,'Marcado como resuelto por quien lo reportó','2026-09-21 12:12:15');
/*!40000 ALTER TABLE `reporte_estado_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporte_imagen`
--

DROP TABLE IF EXISTS `reporte_imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporte_imagen` (
  `id_imagen` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_reporte` bigint unsigned NOT NULL,
  `url_archivo` varchar(500) NOT NULL,
  `orden` tinyint unsigned NOT NULL DEFAULT '1',
  `fecha_carga` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_imagen`),
  KEY `idx_imagen_reporte` (`id_reporte`,`orden`),
  CONSTRAINT `fk_imagen_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `chk_imagen_orden` CHECK ((`orden` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporte_imagen`
--

LOCK TABLES `reporte_imagen` WRITE;
/*!40000 ALTER TABLE `reporte_imagen` DISABLE KEYS */;
INSERT INTO `reporte_imagen` VALUES (2,17,'/uploads/reportes/aec051e3001c4bc3bd305d4ece6240cd.jpg',1,'2026-09-21 12:13:48');
/*!40000 ALTER TABLE `reporte_imagen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporte_seguimiento`
--

DROP TABLE IF EXISTS `reporte_seguimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporte_seguimiento` (
  `id_reporte` bigint unsigned NOT NULL,
  `id_usuario` bigint unsigned NOT NULL,
  `notif_activa` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_inicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_reporte`,`id_usuario`),
  KEY `idx_seguimiento_usuario` (`id_usuario`),
  CONSTRAINT `fk_seguimiento_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `fk_seguimiento_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporte_seguimiento`
--

LOCK TABLES `reporte_seguimiento` WRITE;
/*!40000 ALTER TABLE `reporte_seguimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporte_seguimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporte_voto`
--

DROP TABLE IF EXISTS `reporte_voto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reporte_voto` (
  `id_reporte` bigint unsigned NOT NULL,
  `id_usuario` bigint unsigned NOT NULL,
  `tipo_voto` enum('CONFIRMA','DESMIENTE') NOT NULL,
  `fecha_voto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_reporte`,`id_usuario`),
  KEY `idx_voto_usuario` (`id_usuario`,`fecha_voto`),
  CONSTRAINT `fk_voto_reporte` FOREIGN KEY (`id_reporte`) REFERENCES `reporte` (`id_reporte`) ON DELETE CASCADE,
  CONSTRAINT `fk_voto_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporte_voto`
--

LOCK TABLES `reporte_voto` WRITE;
/*!40000 ALTER TABLE `reporte_voto` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporte_voto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id_rol` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `uq_rol_codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'CIUDADANO','Ciudadano','Usuario general: reporta y recibe alertas geolocalizadas.',1,'2026-09-16 00:04:30'),(2,'MODERADOR','Moderador','Valida, edita o descarta reportes de la comunidad.',1,'2026-09-16 00:04:30'),(3,'ENTIDAD','Entidad de Emergencia','Carabineros, Bomberos, SAMU o Seguridad Ciudadana.',1,'2026-09-16 00:04:30'),(4,'ADMIN','Administrador','Gestiona usuarios, categorías y parámetros del sistema.',1,'2026-09-16 00:04:30');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid_publico` char(36) NOT NULL DEFAULT (uuid()),
  `id_comuna` int unsigned DEFAULT NULL,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `rut` varchar(12) NOT NULL,
  `email` varchar(160) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `url_foto_perfil` varchar(500) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_actualizada` datetime DEFAULT NULL,
  `estado` enum('PENDIENTE','ACTIVO','SUSPENDIDO','ELIMINADO') NOT NULL DEFAULT 'PENDIENTE',
  `email_verificado` tinyint(1) NOT NULL DEFAULT '0',
  `telefono_verificado` tinyint(1) NOT NULL DEFAULT '0',
  `intentos_fallidos` tinyint unsigned NOT NULL DEFAULT '0',
  `bloqueado_hasta` datetime DEFAULT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `puntaje_reputacion` smallint NOT NULL DEFAULT '0',
  `total_reportes_confirmados` int unsigned NOT NULL DEFAULT '0',
  `total_reportes_desmentidos` int unsigned NOT NULL DEFAULT '0',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fecha_eliminacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `uq_usuario_email` (`email`),
  UNIQUE KEY `uq_usuario_uuid` (`uuid_publico`),
  UNIQUE KEY `uq_rut` (`rut`),
  KEY `idx_usuario_estado` (`estado`),
  KEY `idx_usuario_creacion` (`fecha_creacion`),
  KEY `idx_usuario_telefono` (`telefono`),
  KEY `idx_usuario_comuna` (`id_comuna`),
  CONSTRAINT `fk_usuario_comuna` FOREIGN KEY (`id_comuna`) REFERENCES `comuna` (`id_comuna`) ON DELETE SET NULL,
  CONSTRAINT `chk_rut_formato` CHECK (regexp_like(`rut`,_utf8mb4'^[0-9]{7,8}-[0-9Kk]{1}$')),
  CONSTRAINT `chk_usuario_email` CHECK ((`email` like _utf8mb4'%_@_%.__%')),
  CONSTRAINT `chk_usuario_nombres` CHECK ((char_length(trim(`nombres`)) >= 2))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (5,'f1ff78a3-afc2-4b30-81c6-a224e33144c9',NULL,'Renato Esteban','Díaz Soto','20983086-8','renatodiazs@outlook.com','989877562',NULL,'$2b$12$d4gNCMcoadnZcPaT7E.W..ijuZsUCFOKG5PvuDc6Xh6mT74Y2DoXW','2026-09-06 02:11:50','ACTIVO',1,0,0,NULL,NULL,0,0,0,'2026-09-06 02:11:50','2026-09-19 20:16:49',NULL),(10,'1f64ce82-cf8f-4526-8285-ed7ba06e229a',NULL,'Bárbara','Palma Mena','21029298-5','barbarapalmamena@gmail.com','945736951',NULL,'$2b$12$IkJfsgcFUCxf0zZJkYuTX.jQZME9PT8reBvQPLQ/hAxMbg58ff4q.','2026-09-19 18:07:02','ACTIVO',1,0,0,NULL,NULL,0,0,0,'2026-09-19 21:07:02','2026-09-19 21:07:29',NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`usuario_remoto`@`%`*/ /*!50003 TRIGGER `validar_rut_before_insert` BEFORE INSERT ON `usuario` FOR EACH ROW BEGIN
  DECLARE cuerpo VARCHAR(12);
  DECLARE dv CHAR(1);
  DECLARE suma INT DEFAULT 0;
  DECLARE factor INT DEFAULT 2;
  DECLARE i INT;
  DECLARE digito INT;
  DECLARE resto INT;
  DECLARE dv_calc CHAR(1);

  
  SET cuerpo = SUBSTRING_INDEX(NEW.rut, '-', 1);
  SET dv = UPPER(SUBSTRING_INDEX(NEW.rut, '-', -1));

  
  SET i = LENGTH(cuerpo);
  WHILE i > 0 DO
    SET digito = CAST(SUBSTRING(cuerpo, i, 1) AS UNSIGNED);
    SET suma = suma + (digito * factor);
    SET factor = IF(factor = 7, 2, factor + 1);
    SET i = i - 1;
  END WHILE;

  SET resto = 11 - (suma % 11);
  IF resto = 11 THEN SET dv_calc = '0';
  ELSEIF resto = 10 THEN SET dv_calc = 'K';
  ELSE SET dv_calc = CHAR(resto + 48); 
  END IF;

  
  IF dv <> dv_calc THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'RUT inválido: dígito verificador incorrecto';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `usuario_consentimiento`
--

DROP TABLE IF EXISTS `usuario_consentimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_consentimiento` (
  `id_consentimiento` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `tipo` enum('PRIVACIDAD','GEOLOCALIZACION','TERMINOS_USO') NOT NULL,
  `version_documento` varchar(20) NOT NULL,
  `aceptado` tinyint(1) NOT NULL,
  `ip_registro` varbinary(16) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_consentimiento`),
  KEY `idx_consentimiento_usuario` (`id_usuario`,`tipo`,`fecha_registro`),
  CONSTRAINT `fk_consentimiento_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_consentimiento`
--

LOCK TABLES `usuario_consentimiento` WRITE;
/*!40000 ALTER TABLE `usuario_consentimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_consentimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_dispositivo`
--

DROP TABLE IF EXISTS `usuario_dispositivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_dispositivo` (
  `id_dispositivo` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `token_push` varchar(255) NOT NULL,
  `plataforma` enum('ANDROID','IOS','WEB') NOT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `version_so` varchar(40) DEFAULT NULL,
  `version_app` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ultima_actividad` datetime DEFAULT NULL,
  PRIMARY KEY (`id_dispositivo`),
  UNIQUE KEY `uq_dispositivo_token` (`token_push`),
  KEY `idx_dispositivo_usuario_activo` (`id_usuario`,`activo`),
  CONSTRAINT `fk_dispositivo_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_dispositivo`
--

LOCK TABLES `usuario_dispositivo` WRITE;
/*!40000 ALTER TABLE `usuario_dispositivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_dispositivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_preferencia`
--

DROP TABLE IF EXISTS `usuario_preferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_preferencia` (
  `id_usuario` bigint unsigned NOT NULL,
  `radio_alerta_metros` smallint unsigned NOT NULL DEFAULT '1000',
  `notif_proximidad_activa` tinyint(1) NOT NULL DEFAULT '1',
  `notif_zona_activa` tinyint(1) NOT NULL DEFAULT '1',
  `notif_email_activa` tinyint(1) NOT NULL DEFAULT '0',
  `silencio_desde` time DEFAULT NULL,
  `silencio_hasta` time DEFAULT NULL,
  `compartir_ubicacion` tinyint(1) NOT NULL DEFAULT '1',
  `reportes_anonimos` tinyint(1) NOT NULL DEFAULT '0',
  `idioma` char(5) NOT NULL DEFAULT 'es-CL',
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  CONSTRAINT `fk_preferencia_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `chk_radio_alerta` CHECK ((`radio_alerta_metros` between 100 and 20000))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_preferencia`
--

LOCK TABLES `usuario_preferencia` WRITE;
/*!40000 ALTER TABLE `usuario_preferencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_preferencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_rol`
--

DROP TABLE IF EXISTS `usuario_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_rol` (
  `id_usuario` bigint unsigned NOT NULL,
  `id_rol` tinyint unsigned NOT NULL,
  `fecha_asignacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `asignado_por` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id_usuario`,`id_rol`),
  KEY `fk_usuariorol_asignador` (`asignado_por`),
  KEY `idx_usuariorol_rol` (`id_rol`),
  CONSTRAINT `fk_usuariorol_asignador` FOREIGN KEY (`asignado_por`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL,
  CONSTRAINT `fk_usuariorol_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE RESTRICT,
  CONSTRAINT `fk_usuariorol_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_rol`
--

LOCK TABLES `usuario_rol` WRITE;
/*!40000 ALTER TABLE `usuario_rol` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_sesion`
--

DROP TABLE IF EXISTS `usuario_sesion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_sesion` (
  `id_sesion` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `id_dispositivo` bigint unsigned DEFAULT NULL,
  `refresh_token_hash` char(64) NOT NULL,
  `ip_origen` varbinary(16) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `fecha_inicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_expiracion` datetime NOT NULL,
  `fecha_revocacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sesion`),
  UNIQUE KEY `uq_sesion_refresh` (`refresh_token_hash`),
  KEY `fk_sesion_dispositivo` (`id_dispositivo`),
  KEY `idx_sesion_usuario_activa` (`id_usuario`,`fecha_revocacion`),
  CONSTRAINT `fk_sesion_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `usuario_dispositivo` (`id_dispositivo`) ON DELETE SET NULL,
  CONSTRAINT `fk_sesion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_sesion`
--

LOCK TABLES `usuario_sesion` WRITE;
/*!40000 ALTER TABLE `usuario_sesion` DISABLE KEYS */;
INSERT INTO `usuario_sesion` VALUES (4,10,NULL,'9de2a1b32bed21b4bd7b61ad188b9294ffa0e153ff2b45946b1a81098c576efc',_binary '�9A3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/2.2553.1 Chrome/152.0.7977.76 Safari/537.36','2026-09-19 21:07:50','2026-10-19 18:07:50',NULL),(5,10,NULL,'57f9915d2235579136e0ef95df1f27e887ee8f0156aecdd9748a001e037e95a9',_binary '�9A3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/2.2553.1 Chrome/152.0.7977.76 Safari/537.36','2026-09-19 21:10:58','2026-10-19 18:10:58',NULL),(8,10,NULL,'be34d76569cc4aab399d273cfec4c04f151106bdaea961534668ad3fdcf3a050',_binary '�9A3','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36','2026-09-19 21:39:35','2026-10-19 18:39:35',NULL),(10,10,NULL,'d4751aeffbcd559ee6c41973fd430b49f113854064cdacc2598ee213100f789b',_binary '�9A3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/2.2553.1 Chrome/152.0.7977.76 Safari/537.36','2026-09-19 22:15:54','2026-10-19 19:15:54',NULL),(11,5,NULL,'c971b75d75f3e51a66c0b59af8c356d6047c94110cfcc67bd1f93a741e0e4c57',_binary '�(\�\�','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-09-21 11:49:21','2026-10-21 08:49:21',NULL),(12,5,NULL,'5c95203b070d2399015315cef21fe965f0fd90c2689fb88beeec0f626c862385',_binary '�(\�\�','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-09-21 12:04:40','2026-10-21 09:04:40','2026-09-21 09:09:47'),(13,10,NULL,'7415263178425102fcedcd2898cb7401bc25ac3956a954668410df6ef76b495c',_binary '�(\�\�','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-09-21 12:10:14','2026-10-21 09:10:14','2026-09-21 09:18:51'),(14,5,NULL,'40eafb849bec3fa8fddad5150c9cbcb904e63cd1d9a22f11e781f483bb408f73',_binary '�(\�\�','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-09-21 12:19:16','2026-10-21 09:19:16',NULL);
/*!40000 ALTER TABLE `usuario_sesion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_token`
--

DROP TABLE IF EXISTS `usuario_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_token` (
  `id_token` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `tipo` enum('VERIFICACION_EMAIL','RECUPERACION_PASSWORD','VERIFICACION_SMS') NOT NULL,
  `token_hash` char(64) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_expiracion` datetime NOT NULL,
  `fecha_uso` datetime DEFAULT NULL,
  `ip_solicitud` varbinary(16) DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  UNIQUE KEY `uq_usuario_token_hash` (`token_hash`),
  KEY `idx_token_usuario_tipo` (`id_usuario`,`tipo`,`fecha_expiracion`),
  CONSTRAINT `fk_token_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_token`
--

LOCK TABLES `usuario_token` WRITE;
/*!40000 ALTER TABLE `usuario_token` DISABLE KEYS */;
INSERT INTO `usuario_token` VALUES (4,10,'VERIFICACION_EMAIL','4d491adb2f0490def100425ee635db9ea37780b1eac3a73d3f722f2970a45151','2026-09-19 21:07:02','2026-09-20 18:07:02','2026-09-19 18:07:29',_binary '�9A3');
/*!40000 ALTER TABLE `usuario_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zona_segura`
--

DROP TABLE IF EXISTS `zona_segura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zona_segura` (
  `id_zona_segura` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint unsigned NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `centro` point NOT NULL /*!80003 SRID 4326 */,
  `radio_metros` smallint unsigned NOT NULL DEFAULT '500',
  `direccion_referencia` varchar(255) DEFAULT NULL,
  `notif_activa` tinyint(1) NOT NULL DEFAULT '1',
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_zona_segura`),
  UNIQUE KEY `uq_zona_usuario_nombre` (`id_usuario`,`nombre`),
  SPATIAL KEY `spx_zona_centro` (`centro`),
  KEY `idx_zona_usuario_activa` (`id_usuario`,`activa`),
  CONSTRAINT `fk_zona_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `chk_zona_radio` CHECK ((`radio_metros` between 100 and 10000))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zona_segura`
--

LOCK TABLES `zona_segura` WRITE;
/*!40000 ALTER TABLE `zona_segura` DISABLE KEYS */;
/*!40000 ALTER TABLE `zona_segura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'rbalerta_db'
--

--
-- Dumping routines for database 'rbalerta_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-24  0:15:01
